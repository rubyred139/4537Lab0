const MESSAGES = {
	SUCCESS: "Excellent memory!",
	FAIL: "Wrong order!",
	INVALIDBUTTONINPUT:
		"Invalid input! Please choose a number between 3 and 7.",
};
